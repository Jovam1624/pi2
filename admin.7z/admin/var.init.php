<?php
  /**
   * Faire l'assignation des variables ici avec les isset() ou !empty()
   */
   
   
	if(empty($_GET['p']))
	{
		$_GET['p'] = '';
	}
    
	
	if(empty($_GET['id']))
	{
		$_GET['id'] = '';
	}
	
   if(empty($_GET['cat']))
	{
		$_GET['cat'] = '';
	}
   
?>