<?php
/**
 * Class VueFooter
 * 
 * 
 * @author Jonathan Martel
 * @version 1.0
 * @update 2013-12-11
 * @license Creative Commons BY-NC 3.0 (Licence Creative Commons Attribution - Pas d’utilisation commerciale 3.0 non transposé)
 * @license http://creativecommons.org/licenses/by-nc/3.0/deed.fr
 * 
 */


class VueFooter {

	public function AfficheFooter()
	{
	?>
	<!-- début footer -->
    
            </div>

    <!-- jQuery  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
   
    <script src="js/bootstrap.min.js"></script>
   <script src="js/articles.js"></script>
   <script src="js/sondage-admin.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>

	<?php
	}
	

}
?>