<?php 		
	$oControleur = new Controleur();
	$oControleur->gerer();

?>
			