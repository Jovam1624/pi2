<?php
	define("HOST","localhost");
	define("USER","e1395254");
	define("PASS","jovam");
?>
